<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1> Autenticação </h1>
        
        <form action="login.php" method="post">
            
            Usuário: <input type="text" name="usuario" size="20"/> <br>
            Senha: <input type="password" name="senha" size="20"/> <br>
            <br>
            <input type="submit" value="Entrar"/> <br>
            
        </form>
         
    </body>
</html>
